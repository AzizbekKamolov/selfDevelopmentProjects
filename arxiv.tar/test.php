<?php
echo "hello horld";
print_r($_GLOBALS);
echo "<br>";
echo 9+3;
